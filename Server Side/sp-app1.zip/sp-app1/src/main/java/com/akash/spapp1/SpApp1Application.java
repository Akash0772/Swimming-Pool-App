package com.akash.spapp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpApp1Application.class, args);
	}

}

package com.akash.spapp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
